<?php
$subTotal = 0;
$total = 0;
?>
<?php if(session('cart')): ?>
<?php $no = 1; ?>
<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td width="40px"><?php echo e($no); ?></td>
    <td width="80px">
        <input type="hidden" name="kode" class="form-control" value="<?php echo e($item['kode']); ?>">
        <label for=""><?php echo e($item['kode']); ?></label>
    </td>
    <td width="200px">
        <input type="hidden" id="cartId" name="cartId" value="<?php echo e($item['id']); ?>">
        <input type="hidden" id="produkId" name="produkId" value="<?php echo e($item['produkId']); ?>">
        <input type="hidden" id="gudangId" name="gudangId" value="<?php echo e($item['gudangId']); ?>">
        <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>" title="contact-img" class="rounded me-3" height="35" />
        <p class="m-0 d-inline-block align-middle text-wrap font-16">
            <?php echo $item['name']; ?>

        </p>
    </td>

    <td width="150px" valign="center">
        <?php echo e($item['gudangName']); ?>

    </td>
    <td width="100px" valign="center">
        <label for=""><?php echo e(uang($item['price'])); ?></label>
    </td>
    <td width="100px" valign="center">
        <input type="text" min="1" value="<?php echo e($item['quantity']); ?>" class="form-control required" id="cartJumlah" data-id="<?php echo e($item['id']); ?>" data-cartprodukid="<?php echo e($item['produkId']); ?>" data-cartgudangid="<?php echo e($item['gudangId']); ?>" placeholder="Jumlah">
    </td>
    <!-- <td width="70px" valign="center" align="center">
        <?php if($item['grosir']=='1'): ?>
        <span class="text-success">Ya</span>
        <?php else: ?>
        <span class="text-warning">Tidak</span>
        <?php endif; ?>
    </td> -->
    <td width="150px">
        <?php
        $subTotal=$item['price']*$item['quantity']
        ?>
        <p id="cartTotal"><?php echo e(uang($subTotal)); ?></p>
    </td>
    <td width="80">
        <a href="javascript:void(0);" id="cartRemove" data-id="<?php echo e($item['id']); ?>" class="btn btn-outline-danger"> <i class="mdi mdi-delete"></i>
        </a>

    </td>
</tr>
<?php
$total += $subTotal;
$no++;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    $(".total-cart").html("<?php echo e(uang($total)); ?>")
    $("#sub-total").val("<?php echo e($total); ?>")
    $("#grand_total_cell").html("<?php echo e($total); ?>")
    $("#total").val("<?php echo e($total); ?>")
    
</script>
<?php else: ?>
<tr>
    <td colspan="9" align="center">Cart Empty</td>
</tr>
<?php endif; ?><?php /**PATH E:\mytoko300523\resources\views/pembelian/cart-table.blade.php ENDPATH**/ ?>