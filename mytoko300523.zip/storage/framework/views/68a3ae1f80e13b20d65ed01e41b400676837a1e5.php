


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">

            <h4 class="page-title">Ubah Role</h4>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">

                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>


                <?php echo Form::model($role, ['method' => 'PATCH','route' => ['roles.update', $role->id]]); ?>

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Name:</strong>
                            <!-- <?php echo Form::text('alias', null, array('placeholder' => 'Name','class' => 'form-control')); ?> -->
                            <input type="text" name="name" placeholder="Name" value="<?php echo e($role->alias); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">

                        <strong>Permission:</strong>
                        <br />
                        <div class="row">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($value->induk_id==null or $value->induk_id==0): ?>
                            <div class="col-lg-4 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <span class="font-16 text-info"><?php echo e(strtoupper($value->name)); ?></span>
                                    </div>
                                    <div class="card-body">
                                        <label><b><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                                                <?php echo e($value->name); ?></b> <small><?php echo e($value->keterangan??'Semua Akses'); ?><br> <?php if($value->name=='show-all'): ?> (<b class="text-danger">Fitur Super Admin</b>) <?php endif; ?> </small></label>
                                        <br>
                                        <?php $__currentLoopData = $value->sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label style="margin-left: 10px;"><?php echo e(Form::checkbox('permission[]', $v->id, in_array($v->id, $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                                            <?php echo e($v->name); ?> <small><?php echo e($v->keterangan??'Hanya Fitur Ini'); ?></small></label>
                                        <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <button type="submit" class="btn btn-primary float-end">Simpan Perubahan</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>



            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mytoko300523\resources\views/roles/edit.blade.php ENDPATH**/ ?>