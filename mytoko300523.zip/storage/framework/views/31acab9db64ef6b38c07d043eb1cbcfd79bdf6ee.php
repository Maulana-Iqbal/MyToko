</div> <!-- end card-body -->
</div>
<!-- end card -->


<!-- end row -->

</div> <!-- end col -->
</div>
<!-- end row -->
</div>
<!-- end container -->
</div>
<!-- end page -->

<footer class="footer footer-alt">
<?php echo e(date('Y')); ?> © <?php echo e(website(1)->nama_website); ?>

</footer>

<!-- bundle -->
<script src="<?php echo e(asset('hy_assets/js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('hy_assets/js/app.min.js')); ?>"></script>

</body>
</html>
<?php /**PATH E:\mytoko300523\resources\views/auth/authFooter.blade.php ENDPATH**/ ?>