</div> <!-- end card-body -->
</div>
<!-- end card -->

{{-- <div class="row mt-3">
    <div class="col-12 text-center">
        <p class="text-muted">Don't have an account? <a href="pages-register.html" class="text-muted ms-1"><b>Sign Up</b></a></p>
    </div> <!-- end col -->
</div> --}}
<!-- end row -->

</div> <!-- end col -->
</div>
<!-- end row -->
</div>
<!-- end container -->
</div>
<!-- end page -->

<footer class="footer footer-alt">
{{date('Y')}} © {{  website(1)->nama_website }}
</footer>

<!-- bundle -->
<script src="{{ asset('hy_assets/js/vendor.min.js') }}"></script>
<script src="{{ asset('hy_assets/js/app.min.js') }}"></script>

</body>
</html>
